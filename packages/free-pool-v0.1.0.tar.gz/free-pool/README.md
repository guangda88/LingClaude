# free-pool

可复用的免费模型池（Free Model Pool），提供 OpenAI 兼容的 `/v1/chat/completions` 和 `/v1/models` 接口。

## 特性
- 免费路由自动发现（`sync_free_models.py`，平台 `/v1/models`）
- 只增不删，失效路由标记 `default_off`（保守策略）
- 本地桥：OpenCode Zen (`oc_free_bridge.py`)、CodeArts (`codearts_bridge.py`）
- 健康分 + 桶调度（auto/code/fast/long/vision） + 限流
- OpenAI 兼容 API（/v1/chat/completions, /v1/models）

## 安装
```bash
pip install -e .
```

## 配置
复制 `.env.example` 为 `.env` 并按需修改。或使用环境变量。

## 使用
```bash
# 同步免费模型
free-pool-sync

# 启动网关
free-pool-serve
```

## 架构
- `gateway_main.py` / `free_pool.py`：网关核心
- `sync_free_models.py`：路由同步
- `oc_free_bridge.py`：OpenCode Zen 桥（端口 4100）
- `codearts_bridge.py`：CodeArts 桥（端口 4110）
- `routes.example.json`：路由示例
